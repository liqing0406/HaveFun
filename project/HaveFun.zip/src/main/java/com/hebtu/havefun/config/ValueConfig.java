package com.hebtu.havefun.config;

/**
 * @author PengHuAnZhi
 * @createTime 2020/11/23 10:28
 * @projectName HaveFun
 * @className ValueConfig.java
 * @description TODO
 */
public class ValueConfig {
    public static Integer USER_ID= 10000000;
    public static String SERVER_URL = "http://10.7.90.253:8080/";
//    public static String SERVER_URL = "http://39.105.43.3:8080/";
//    public static String SERVER_URL = "http://192.168.43.41:8080/";
}